<title><?php echo e('Yosmar B. - Blog | '.$post->name); ?></title>

<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> 
    <div class="container py-8 mx-auto">
        <h1 class="text-4xl font-bold text-gray-400"><?php echo e($post->name); ?></h1>

        <div class="text-lg text-gray-900 mb-2 ">
            <?php echo $post->extract; ?>

        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            
            
            
            <div class="col-span-2">
                <figure>

                    <img class="w-full h-80 object-cover object-center" src=" <?php if($post->image): ?><?php echo e(url('storage/'.$post->image->url)); ?> <?php else: ?> https://cdn.pixabay.com/photo/2023/01/10/21/31/trees-7710539_960_720.jpg <?php endif; ?>" alt="">
                </figure>

                <div class="text-base text-gray-500 mt-4">
                    <?php echo $post->body; ?>

                </div>

            </div>
            
            <aside>

                <h1 class="text-2xl font-bold text-gray-800 mb-4">Mas en <?php echo e($post->category->name); ?></h1>

                <ul>
                    <?php $__currentLoopData = $similares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a class="flex mb-3" href="<?php echo e(route('posts.show', $similar)); ?>"> 
                                <img class="w-36 h-20 object-cover object-center" src="<?php if($similar->image): ?><?php echo e($similar->image->url); ?> <?php else: ?> https://cdn.pixabay.com/photo/2023/01/10/21/31/trees-7710539_960_720.jpg <?php endif; ?>" alt="">
                                <span class="ml-2 text-indigo-700"><?php echo e($similar->name); ?></span>
                            </a>
                            
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </aside>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\blog\resources\views/posts/show.blade.php ENDPATH**/ ?>