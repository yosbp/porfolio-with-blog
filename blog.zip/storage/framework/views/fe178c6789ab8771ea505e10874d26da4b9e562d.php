

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>

    <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-secondary btn-sm float-right">Nuevo Post</a>
    
    <h1>Listado de Posts</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('info')): ?>
    <div class="alert alert-danger">
        <strong><?php echo e(session('info')); ?></strong>    
    </div>        
    <?php endif; ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.posts-index')->html();
} elseif ($_instance->childHasBeenRendered('uTimESC')) {
    $componentId = $_instance->getRenderedChildComponentId('uTimESC');
    $componentTag = $_instance->getRenderedChildComponentTagName('uTimESC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('uTimESC');
} else {
    $response = \Livewire\Livewire::mount('admin.posts-index');
    $html = $response->html();
    $_instance->logRenderedChild('uTimESC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\blog\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>