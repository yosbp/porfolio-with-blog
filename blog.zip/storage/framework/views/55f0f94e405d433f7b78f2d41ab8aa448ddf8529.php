<div class="card">

    <div class="card-header">
        <input wire:model="search" type="text" class="form-control" placeholder="Ingrese el nombre de un o correo de un usuario">
    </div>

    <?php if($users->count()): ?>
        <div class="card-body">
            <table class="table table-striped">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th colspan="2"></th>
                </tr>

                <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->id); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td width="10px">
                                <a class="btn btn-primary btn-sm" href="<?php echo e(route('admin.users.edit', $user)); ?>">Editar</a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="card-footer">
            <?php echo e($users->links()); ?>

        </div>

    <?php else: ?>
        <strong class="my-4 mx-auto">No hay ningun registro</strong>
    <?php endif; ?>
    

</div><?php /**PATH C:\laragon\www\blog\resources\views/livewire/admin/users-index.blade.php ENDPATH**/ ?>