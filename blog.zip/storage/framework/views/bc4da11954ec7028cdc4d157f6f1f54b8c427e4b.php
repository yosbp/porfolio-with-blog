<a class="h-3" href="/blog">
    <img style="height: 8rem" src="<?php echo e(Storage::url('img/logo.png')); ?>" alt="">
</a>
<?php /**PATH C:\laragon\www\blog\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>