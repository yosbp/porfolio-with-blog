
                <div class="form-group">
                    <?php echo Form::label('name', 'Nombre'); ?>

                    <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder'=> 'Indica el nombre del post']); ?>


                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <?php echo Form::label('slug', 'Slug'); ?>

                    <?php echo Form::text('slug', null, ['class' => 'form-control', 'placeholder'=> 'Indica el slug del post', 'readonly']); ?>


                    <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <?php echo Form::label('category_id', 'Categorias'); ?>

                    <?php echo Form::select('category_id', $categories, null, ['class'=>'form-control']); ?>


                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                
                <div class="form-group">
                    <p class="font-weight-bold">Etiquetas</p>
                    <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="mr-2">
                            <?php echo Form::checkbox('tags[]', $tag->id, null); ?>

                            <?php echo e($tag->name); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $__errorArgs = ['tags'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <br>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <p class="font-weight-bold">Estado</p>
                    <label class="mx-4">
                        <?php echo Form::radio('status', 1, true); ?>

                        Borrador
                    </label>

                    <label>
                        <?php echo Form::radio('status', 2); ?>

                        Publicado
                    </label>

                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="row mb-3">
                    <div class="col">
                        <div class="image-wrapper">
                            <?php if(isset($post->image)): ?>
                            <img id="picture" src="<?php echo e(Storage::url($post->image->url)); ?>" alt="">
                            <?php else: ?>
                            <img id="picture" src="https://cdn.pixabay.com/photo/2023/01/10/21/31/trees-7710539_960_720.jpg" alt="">
                            <?php endif; ?>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nulla porro doloribus exercitationem laborum facilis recusandae corporis consectetur in fuga at molestias vitae, cum doloremque numquam praesentium distinctio obcaecati quod iste!</p>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <?php echo Form::label('file','Imagen que se mostrara en el post'); ?>

                            <?php echo Form::file('file', ['class'=> 'form-control-file', 'accept' => 'image/*']); ?>

                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Consequatur nam omnis ducimus repellat alias, nesciunt cupiditate esse, voluptatibus odio, earum fuga provident voluptas nisi deserunt exercitationem expedita eos delectus non?
                        </p>
                    </div>

                </div>
                
                <div class="form-group">
                    <?php echo Form::label('extract', 'Extracto'); ?>

                    <?php echo Form::textarea('extract', null, ['class'=>'form-control']); ?>


                    <?php $__errorArgs = ['extract'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <?php echo Form::label('body', 'Cuerpo del Post'); ?>

                    <?php echo Form::textarea('body', null, ['class'=>'form-control']); ?>


                    <?php $__errorArgs = ['body'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"><?php echo e($message); ?></small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div><?php /**PATH C:\laragon\www\blog\resources\views/admin/posts/partials/form.blade.php ENDPATH**/ ?>