<div>
    <!-- I begin to speak only when I am certain what I will say is not better left unsaid. - Cato the Younger -->
</div><?php /**PATH C:\laragon\www\blog\resources\views/components/index-layout.blade.php ENDPATH**/ ?>